#!/bin/bash
#
# Copyright (c) 2023 Oracle and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl/

rm -rf $PROXYHOME
mkdir -p ${PROXYHOME}
ls -lrt $PROXYHOME

java -Xmx64m -Xms64m -jar $KVHOME/lib/kvclient.jar


